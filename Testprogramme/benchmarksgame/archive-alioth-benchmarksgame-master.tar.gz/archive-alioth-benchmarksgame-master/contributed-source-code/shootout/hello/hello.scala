/* The Computer Language Shootout
   http://shootout.alioth.debian.org/
   contributed by Isaac Gouy (Scala novice)
   modified for Scala 2.x by Anthony Borla
*/

object hello extends Application {
  Console.println("hello world")
}

