#!/usr/bin/php
<?php
print "hello world\n";
?>
