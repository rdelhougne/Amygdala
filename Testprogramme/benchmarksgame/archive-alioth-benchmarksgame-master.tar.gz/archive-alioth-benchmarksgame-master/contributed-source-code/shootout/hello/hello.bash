#!/bin/bash
# $Id$
# http://www.bagley.org/~doug/shootout/

echo "hello world"
