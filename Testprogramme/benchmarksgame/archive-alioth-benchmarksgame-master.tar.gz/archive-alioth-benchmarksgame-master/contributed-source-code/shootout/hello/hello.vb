' The Computer Language Shootout
' http://shootout.alioth.debian.org/
' contributed by Isaac Gouy

Imports System

Public Module hello
   Sub Main() 
      Console.WriteLine("hello world") 
   End Sub
End Module
