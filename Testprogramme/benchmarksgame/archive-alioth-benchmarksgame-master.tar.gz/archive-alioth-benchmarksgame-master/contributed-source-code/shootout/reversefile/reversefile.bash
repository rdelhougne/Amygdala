#!/bin/bash
# $Id$
# http://www.bagley.org/~doug/shootout/
# from David N. Welton
tac
