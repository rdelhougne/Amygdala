#!/bin/bash
# $Id$
# http://www.bagley.org/~doug/shootout/

# (use echo to collapse whitespace output from "wc")
echo `wc`
