The Benchmarks Game Debian Alioth Archive
=========================================

Previously, the benchmarks game project and "shootout" project used the now deprecated Debian Alioth hosting service. Some of those project artefacts are archived here.


Contributed Source Code
-----------------------

The plain-text source-code files — contributed to the benchmarks game project and "shootout" project — imported into a Git repository from CVS.

